# JsonFeed

MODX plugin to add a JSON Feed to your site with Template Variables to customize the feed per resource. https://jsonfeed.org/

After Install:
1. update the "templates" you want to list in the installed template. The default is "1".
2. update the Template => TV Access for the custom options

**Friendly URLs must be turned ON**
