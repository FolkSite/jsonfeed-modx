# JsonFeed 1.0.0
- Basic Options
